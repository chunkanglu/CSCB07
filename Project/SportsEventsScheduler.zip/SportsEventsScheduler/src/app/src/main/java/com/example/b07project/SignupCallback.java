package com.example.b07project;

public interface SignupCallback {
    interface CheckDuplicateAdminCallback {
        void checkDuplicateAdminCallback();
    }
    interface CheckDuplicateUserCallback {
        void checkDuplicateUserCallback();
    }
}
