package com.example.b07project;

public class CustomerView {
    public CustomerView(){}
}
