package com.example.b07project;

public interface LoginCallback {
    interface AuthenticateCallback {
        void authenticateCallback(boolean isAdmin);
    }
//    interface AuthenticateCallback {
//        void authenticateUserCallback();
//    }
}
