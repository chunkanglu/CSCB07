package com.example.b07project;

public class AdminView {
    public AdminView(){}
}
