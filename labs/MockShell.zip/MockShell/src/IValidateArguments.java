
public interface IValidateArguments {
	boolean validate();
}
