
public interface ICmd {
	void execute();
}
